<?php
ini_set('error_reporting', E_STRICT);
$myObj->admob_id = "ca-app-pub-5457774416106917~2682227870";
$myObj->admob_banner = "ca-app-pub-5457774416106917/8319290254";
$myObj->admob_inters = "ca-app-pub-5457774416106917/5421664173";

$myJSON = json_encode($myObj);

echo $myJSON;
?>