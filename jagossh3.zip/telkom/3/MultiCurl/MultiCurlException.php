<?php namespace CepzDecoded\PhpMultiCurl;
class MultiCurlException extends \Exception {}
class MultiCurlInvalidParameterException extends MultiCurlException {}
