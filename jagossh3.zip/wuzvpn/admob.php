<?php
ini_set('error_reporting', E_STRICT);
$myObj->admob_id = "ca-app-pub-9899081085574250~9880468061";
$myObj->admob_banner = "ca-app-pub-9899081085574250/8885637519";
$myObj->admob_inters = "ca-app-pub-3940256099942544/8691691433";

$myJSON = json_encode($myObj);

echo $myJSON;
?>