<?php
$serverLoc="37.0373,-95.6164";
?>