<?php
$IPINFO_APIKEY="08482874ab813a"; //put your token between the quotes if you have one
?>