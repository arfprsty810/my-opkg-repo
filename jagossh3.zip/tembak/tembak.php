<?php

require 'XlRequest.php';

function service($str) {
	
	switch ((int) $str) {
		
case 1: return 8110671;
        break;
        
        case 2: return 8110999;//XTRA Kuota PUBG 10GB, 30hr, Rp.10.000//
        break;
                        
        case 3: return 8111124; //Xtra Unlimited Turbo Joox, Rp.1000//
        break;

        case 4: return 8111116; // XTRA Unlimited Turbo Basic, Rp.10.000//
        break;

        case 5: return 8111123; // XTRA Unlimited Turbo VIU, Rp.25.000
        break;
        
        case 6: return 8111117; // XTRA Unlimited Turbo Standart, Rp.20.000//
        break;
                        
        case 7: return 8111120; // XTRA Unlimited Turbo Youtube, Rp.25.000//
        break;
                        
        case 8: return 8111121; // XTRA Unlimited Turbo Tiktok, Rp.25.000//
        break;
                        
        case 9: return 8111122; // XTRA Unlimited Turbo Netflix, Rp.25.000//
        break;
                        
        case 10: return 8111118; // XTRA Unlimited Turbo Super, Rp.30.000//
        break;
                        
        case 11: return 8111119;  // XTRA Unlimited Turbo Premium, Rp.50.000//
        break;
                        
        case 12: return 8211107;
        break;
                        
        case 13: return 8211108;
        break;
                        
        case 14: return 8211109;
        break;

        case 15: return 8210882;
        break;

        case 16: return 8210883;
        break;

        case 17: return 8210884;
        break;

        case 18: return 8210885;
        break;

        case 19: return 8210886;
        break;

        case 20: return 8210965;
        break;

        case 21: return 8211231;
        break;
        
        case 22: return 8110801;
        break;
        
        case 23: return 8211370;
        break;
        
        case 24: return 8211371;
        break;
        
        case 25: return 8110803;
        break;
        
        case 26: return 8110800;
        break;
        
        case 27: return 8110799;
        break;
        
        case 28: return 8110812;
        break;
        
        case 29: return 8110813;
        break;
        
        case 30: return 8211369;
        break;
        
        case 31: return 8211928;
        break;
        
        case 32: return 8211929;
        break;
        
        case 33: return 8211849;
        break;
        
        case 34: return 8211378;
        break;
        
        case 35: return 8211379;
        break;
        
        case 36: return 8211380;
        break;
        
        case 37: return 8211381;
        break;
        
        case 38: return 8211382;
        break;
        
        case 39: return 8211383;
        break;
        
        case 40: return 8110912;
        break;
        
        case 41: return 8110919;
        break;
        
        case 42: return 8110923;
        break;
        
        case 43: return 8110926;
        break;
        
        case 44: return 8110913;
        break;
        
        case 45: return 8110935;
        break;
        
        case 46: return 8110936;
        break;
        
        case 47: return 8110916;
        break;
        
        case 48: return 8110970;
        break;
        
        case 49: return 8110968;
        break;
        
        case 50: return 8110969;
        break;
        
        case 51: return 8110973;
        break;
        
        case 52: return 8110960;
        break;
        
        case 53: return 8212226; // XTRA Combo 5GB + 5GB, 30hr, Rp.54.000//
        break;
        
        case 54: return 8212227; // XTRA Combo 10GB + 10GB, 30hr, Rp.81.000//
        break;
        
        case 55: return 8212228; // XTRA Combo 15GB + 15GB, 30hr, Rp.114.000//
        break;
        
        case 56: return 8212229; // XTRA Combo 20GB + 20GB, 30hr, Rp.159.000//
        break;
        
        case 57: return 8212229; //XTRA Combo VIP 5GB + 5GB, 30hr, Rp 62.000//
        break;
        
        case 58: return 8212221; //XTRA Combo VIP 10GB + 10GB, 30hr, Rp 89.000//
        break;
        
        case 59: return 8212220; //XTRA Combo VIP 15GB + 15GB, 30hr, Rp 120.000//
        break;
        
        case 60: return 8212219; //XTRA Combo VIP 20GB + 20GB, 30hr, Rp 164.000//
        break;
        
        case 61: return 8212358; //XTRA Combo Lite 2GB + 1GB, 30hr, Rp 20.000//
        break;
        
        case 62: return 8212359; //XTRA Combo Lite 3.5GB + 1.5GB + 1GB, 30hr, Rp 33.000//
        break;
        
        case 63: return 8212360; //XTRA Combo Lite 6GB + 2GB + 3GB, 30hr, Rp 45.000//
        break;
        
        case 64: return 8212361; //XTRA Combo Lite 11GB + 4GB + 6GB, 30hr, Rp 65.000//
        break;
        
        case 65: return 8212362; //XTRA Combo Lite 21GB + 4GB + 12GB, 30hr, Rp 105.000//
        break;
        
        case 66: return 8212363; //XTRA Combo Lite 31GB + 6GB + 18GB, 30hr, Rp 125.000//
        break;
        
        case 67: return 8111159; //BONUS KUOTA 2GB, 7hr, Rp 0//
        break;
        
        case 68: return 8111202; //XTRA Gift Telp&SMS, 1hr, Rp 0 //
        break;
        
        case 69: return 8111199; //XTRA Gift 100mb, 1hr, Rp 0 //
        break;
        
        case 70: return 8111224; //XTRA Combo Gift 1GB + 1GBYT + Unli YT 01-06, 30hr, Rp 25.000 //
        break;
        
        case 71: return 8111223; //XTRA Combo Gift 2GB + 2GBYT + Unli YT 01-06, 30hr, Rp 35.000 //
        break;
        
        case 72: return 8111201; //XTRA Gift 1GB, 1hr, Rp 0 //
        break;
        
		default:
		
	}
}
if (isset($_SESSION['simpan_nomor']) && isset($_POST['reg']))
{
	$msisdn = $_SESSION['simpan_nomor'];

	$idService = service($_POST['reg']);

	if( !empty($_POST['manual']) )
	{
		$idService = $_POST['manual'];
	}
	try
	{
		$request2 = new XlRequest();
			$fil = fopen('count_file.txt', 'r');
		    $dat = fread($fil, filesize('count_file.txt')); 
		    $dat+1;
		    fclose($fil);
		    $fil = fopen('count_file.txt', 'w');
		    fwrite($fil, $dat+1);
		    fclose($fil);
		    $register2 = $request2->register($msisdn,$idService,$_SESSION['session']);
		    $hasil = json_decode($register2, TRUE);
        	$index  = sizeof($hasil, 1);
        	$success ="btn-success";
        	$warning ="btn-danger";

		    if ($index == "14") {
        		echo "<div class=".$success.">Terima kasih sudah berkunjung ke JAGOANSSH<p>Transaksi anda sedang di proses.</div>";
                }else if ($index == "2"){

                    if ($hasil['message'] == 'Invalid Session'){
                        echo '<script>confirm("Sesi Kamu telah berakhir, Silakan Login Kembali!");</script>';
                        $session = session_destroy();
                        echo "<script type=\"text/javascript\" language=\"javascript\">
                     window.location.replace(\"Login.php\");
                 </script>";
                 }
                 else{
            		echo "<div class=".$warning.">Paket tidak dapat di beli saat ini<p>Silahkan untuk kembali beberapa saat lagi.</div>";
        		}
		}
			
	}
	catch(Exception $e) {}
 }
?>
