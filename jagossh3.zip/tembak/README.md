# XLRequest
Tembak paket xl

chmod 777 count_file.txt

group fb : https://web.facebook.com/groups/1528714680491086/
https://github.com/adipatiarya/XLRequest/archive/XlRequest-V2.0.zip


--cara instalasi----
misalkan semua file ditaruh di public_html

1.Edit index.html cari kata 192.168.8.1.101/count.php 
kemudiann ubah 192.168.8.1.101 sesuai dengan domain Yang digunakan
misal webmu.com/count.php


2.Edit index.html dan ubah form action sesuai domain anda

webmu.com/tembak.php



Request Tembak Xl terbaru cek : https://gretonger.mobi/xl
MORAL DONATION
via pulsa gpp gan biar admin semangat updte script
081382617114
