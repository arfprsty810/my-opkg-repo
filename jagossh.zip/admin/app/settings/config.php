<?php
/*
 * All In One SSH Configuration File
 * Copyright, 2014 AIOSSH by Widigdo Dimas Pratama.
 * Date Created: 18 March 2015
 */
 
/* Toggle Dev Mode */
$conf['DEV_MODE'] = 0; // Toggle Develop Mode

/* Database Connection */
include('../app/conn/db.conn.php');

/* Function */
include('app/settings/function.php');

 ?>