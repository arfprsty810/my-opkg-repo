<div class="col-md-8 col-md-offset-2 probootstrap-section probootstrap-animate">
  <div class="probootstrap-pricing popular">
          <h1>Prviacy Policy</h1>
          <h3>Logging</h3>
<p class="lead">Like another web sites, We do make use of log files. We just collect your IP Address, Browser Type, Internet Service Provider (ISP), TimeStamp, Referring & Exit pages, and number of clicks to analyze trends, administer the site, track visitor/users activity around the site, and gather demographic information. IP address, and other such information are not linked to any information that is personally identifiable. If forced by law we may provide your information to 3rd party. <span style='text-decoration:underline;'><strong>But we do not collect or log traffic data or browsing activity from individual users connected to our SSH/VPN Service. We are committed to your privacy.</strong></span></p>
<h3>Email</h3>
<p class="lead">Email is optional, you may enter your email when creating account to receive notification such as your account details copy, account renew notification, account expiring notification. And we may use your email to promote our service like sending promotion & offers to your email. We will never spam you, you can always unsubscribe by using unsubscribe link on the email.</p>

<h3>Cookies</h3>
<p class="lead">We use third party cookies, pixels and website analytics tools to track advertisements or sales promotions and to understand which pages on the Site get visitors. If you wish to disable cookies, you may disable it through your browser option.</p>
</div>
</div>