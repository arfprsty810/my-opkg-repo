<div class="col-md-8 col-md-offset-2 probootstrap-section probootstrap-animate">
  <div class="probootstrap-pricing popular">
          <h1>Terminos y Condiciones</h1>
  <div align="left">Al utilizar nuestro servicio, debe aceptar nuestros términos de servicio. Debe aceptar todos nuestros términos y condiciones. Le permitimos navegar por Internet, descargar, cargar con nuestro servicio. Pero está PROHIBIDO:
  <ul>
  <li>¡Enviar, transmitir o recibir cualquier contenido ilegal a través del Servicio que viole cualquier ley nacional, local e internacional aplicable!.</li>
  <li>DDOS o cualquier actividad de Hacking</li>
  <li>Torrent (¡Torrent no está permitido!)</li>
  <li>Correo no deseado (¡Estrictamente prohibido enviar correo no deseado!)</li>
  <li>Publicar o transmitir a través de nuestro Servicio cualquier material ilegal, amenazante, dañino, acosador, abusivo, racista, odioso, étnico u objetable de cualquier otro tipo, incluido, entre otros, cualquier material que promueva una conducta que pueda constituir un delito penal. , dar lugar a responsabilidad civil o violar cualquier ley nacional, local o internacional aplicable.
  <li>Comparta o vuelva a publicar su cuenta en otro</li>
  <li>Solo puede usar nuestro servicio para 2 conexiones simultáneas</li>
  <li>Cargar, descargar, reproducir, publicar o distribuir cualquier contenido protegido por derechos de autor o cualquier otro derecho de propiedad sin tener primero el permiso del propietario del contenido de propiedad.</li>
  </ul>
<p>Usted acepta que accede al Sitio y utiliza el Servicio a su propia discreción y riesgo. Todos los contenidos de este sitio web utilizan nuestro propio servidor privado, por lo que no permitimos que nuestro contenido se difunda sin nuestro permiso para evitar el abuso de los datos que proporcionamos.</p>
<p>Si encontramos alguno de nuestros contenidos en un sitio web que no tiene nuestro permiso, denunciaremos su sitio web como robo de contenido a Google y a la DMCA y es posible que emprendamos acciones legales. Por lo tanto, use nuestro servicio con prudencia y obedezca nuestros términos de servicio. </p>
</div>
</div>
</div>