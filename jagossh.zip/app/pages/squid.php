<div id="ndexi" style="display:none;">squid-proxy</div>
<div id="where" style="display:none;">squid-proxy</div>
<!-- START: section -->
  <section class="probootstrap-section">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 section-heading mb50 text-center probootstrap-animate">
          <h2>We provide best experience for you</h2>
        </div>
      </div>
    <p class="text-center probootstrap-animate">
     <span class="badge badge-success mb-3 p-3">Free SSH VPN Accounts</span>
    <span class="badge badge-warning mb-3 p-3">Unlimited Bandwidth VPS</span>
    <span class="badge badge-primary mb-3 p-3">Full Speed Servers</span>
    <span class="badge badge-success mb-3 p-3">Private Account</span>
    <span class="badge badge-info mb-3 p-3">Hide Your IP Adrres</span>
    <span class="badge badge-primary mb-3 p-3">Fast SSH  VPN Servers</span>
  </p> 
  <p class="text-center probootstrap-animate">
    <span class="label label-danger">No DDOS</span>
    <span class="label label-danger">No Fraud</span>
    <span class="label label-danger">No Hacking</span>
    <span class="label label-danger">No Spam</span>
  </p> 
</div>
</section>
<!-- END: section -->
<?php
include('app/ads/link.php');
?>
<section class="probootstrap-section">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center section-heading probootstrap-animate">
          <h2>Squid Proxy Server list & status</h2>
          <p class="lead">All SSH and VPN servers can use Squid proxy by using an IP host directly</p>
        </div>
      </div>
     <div class="row">
    <table class="table table-bordered probootstrap-animate">
    <thead>
       <tr>
        <th>Squid Proxy</th>
        <th>Detail</th>
        <th>Port</th>
      </tr>
    </thead>
       <tbody>
        <tr>
        <td>Proxy.jagoanssh.com</td>
        <td>Suport All Server</td>
        <td>80, 8080, 3128</td>
      </tr> 
          <tr>
        <td>Host Server</td>
        <td>Suport directly</td>
        <td>8080</td>
      </tr>   
                 </tbody>
  </table>
</div>
</div>
</section>