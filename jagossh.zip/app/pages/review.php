 <!-- Main component for a primary marketing message or call to action -->
    <div id="where" style="display:none;">tester</div>

<div class="container">
  <div class="row">
      <br/><br/><br/>
  <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/id_ID/sdk.js#xfbml=1&version=v2.4&appId=1821005851492806";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


<div class="col-lg-12" align="center" text-align="center" style="margin-bottom:40px;"><h4>Please leave your comment or your speedtest proof below</h4>We need your feedback to improve our service and serve you better than before.</div>
<div class="col-lg-8 col-lg-offset-2">
<div class="fb-comments" data-href="https://redefinet.com/" data-width="100%" data-numposts="10"></div>
</div>
      </div>
	  </div>
        <br/><br/><br/>