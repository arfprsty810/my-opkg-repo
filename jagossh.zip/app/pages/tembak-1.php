
<div id="ndexi" style="display:none;">Tembak Axis</div>
<div id="where" style="display:none;">Tarif Hura-Hura</div>

<p>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 300x250 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="1825913338"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="col-xs-12 animation" data-animation="fadeIn">
    <div class="modal-content">
<div class="container">
<center>
         <h5>We provide best experience for you</h5>
         <h5>We provide best service for you</h5>
         <h5>We provide best security for you</h5>
      <p class="lead" style="font-size:1.3em;">
                <span class="label label-success">Premium Server</span>
    <span class="label label-warning">Unlimited Bandwidth</span>
    <span class="label label-primary">Full Speed</span>
    <span class="label label-success">Private Account</span>
    <span class="label label-info">Hide Your IP</span>
    <span class="label label-warning">Simple & Easy</span>
    <span class="label label-primary">High Quality</span> 
    <span class="label label-warning">Instant Create</span>  
    
  </p> 
  <p class="lead" style="font-size:1.3em;margin-top:-20px;">
    <span class="label label-danger">No DDOS</span>
    <span class="label label-danger">No Fraud</span>
    <span class="label label-danger">No Hacking</span>
    <span class="label label-danger">No Spam</span>
    <span class="label label-danger">No Repost Account</span>
  </p> 
</center>
</div>
</div>
</p>
<div class="modal-content">
<div class="row">
<div align="center">
    <h4>Tembak Tarif Axis</h4>
</div>
</div>
</div>
</p>
<div class="modal-content">
    <div class="container text-center">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <h2>Kenapa Harus Pindah Tarif?</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-offset-1 col-sm-12 col-md-12 col-lg-10">
                <div class="features-list">
                    <div class="row">
                        <div class="col-sm-6 col-md-3 col-lg-3">
                            <div class="feature-block bootdey" style="visibility: visible;">
                                <div class="ico fa fa-money"></div>
                                <div class="name">
                                   HARGA LEBIH MURAH
                                </div>
                                <div class="text">Harga lebih murah dari pada beli langsung</div>
                                <div class="more">
                                <div style="height:10px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-lg-3">
                            <div class="feature-block bootdey" style="visibility: visible;">
                                <div class="ico fa fa-calendar-check-o"></div>
                                <div class="name">
                                 BISA BELI KAPAN SAJA
                                </div>
                                <div class="text">Tanpa harus menunggu jam tertentu / promo (Bahkan untuk SC baru bisa langsung memakai layanan ini)</div>
                                <div class="more">
                                <div style="height:10px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-lg-3">
                            <div class="feature-block bootdey" style="visibility: visible;">
                                <div class="ico fa fa-key"></div>
                                <div class="name">
                                  KE AMANAN DATA DI JAMIN
                                </div>
                                <div class="text">Semua data tidak disimpan di dalam server kami jadi tidak ada data yang di rekam</div>
                                <div class="more">
                                <div style="height:10px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-lg-3">
                            <div class="feature-block bootdey" style="visibility: visible;">
                                <div class="ico fa fa-check"></div>
                                <div class="name">
                                  LEGAL
                                </div>
                                <div class="text">Semua pembelian ini legal karena pihak provider yang menyediakan</div>
                                <div class="more">
                                <div style="height:10px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<p>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- iklan link -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="8185744498"
     data-ad-format="link"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
</p>
<div class="col-lg-6 col-lg-offset-3">
<div class="panel panel-primary">
<div class="panel-heading"> <h3 class="panel-title text-center "><strong>Pindah Tarif AXIS</strong></h3></div>                                 
<div class="well" style="height:100%px;" id="myModalLabel">
<center>
    <a class="btn btn-lg btn-success btn-block" href='https://jagoanssh.com/axis/login/'>My Axis</a>
    
    <button onclick="generate()" class="btn btn-lg btn-primary btn-block"/>Pindah HURA-HURA</button>
    <a id="download" href="https://jagoanssh.com/axis/" style="display:none"/></a>
    
<br>
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 300x250 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-5543899617659266"
     data-ad-slot="1825913338"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
<div class="testimonials">
              <div class="active item">
                 <div class="carousel-info">
<div class="center">
                  <blockquote><center><h6><b>Silahkan Masuk Ke Myaxis Dahulu</b></h6></center></blockquote>
                  <blockquote><center><h6><b>Setelah berhasil Masuk Silahkan kembali Lagi Ke Sini</b></h6></center></blockquote>
                  <blockquote><center><h6><b>Untuk Pindah Tarif Pastikan Pulsa Min 5k</b></h6></center></blockquote>
                  <blockquote><center><h6><b>Terimakasih JagaonSSH</b></h6></center></blockquote>
                    </div>
                  </div>

</form>
&copy; 2019 by <a href="http://jagoanssh.com">Jagoanssh.com</a> All Rights Reserved.
</center>
</form>
</div>
</div>
</div>
</div>
</div>