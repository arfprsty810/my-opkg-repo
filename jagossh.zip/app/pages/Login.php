<?php
include('ads/ads.php');
?>
<div class="modal-content">
<div class="container">
<center>    
         <h4><small style="color:grey;">We provide best experience for you.</small></h4>
     </center>  

    <center>  
      <p class="lead" style="font-size:1.3em;">
                <span class="label label-success">Premium Server</span>
    <span class="label label-warning">Unlimited Bandwidth</span>
    <span class="label label-primary">Full Speed</span>
    <span class="label label-success">Private Account</span>
    <span class="label label-info">Hide Your IP</span>
    <span class="label label-warning">Simple & Easy</span>
    <span class="label label-primary">High Quality</span> 
    <span class="label label-warning">Instant Create</span>  
    
  </p> 
  <p class="lead" style="font-size:1.3em;margin-top:-20px;">
    <span class="label label-danger">No DDOS</span>
    <span class="label label-danger">No Fraud</span>
    <span class="label label-danger">No Hacking</span>
    <span class="label label-danger">No Spam</span>
    <span class="label label-danger">No Repost Account</span>
  </p> 
   </center>
</div>  
</div>
<p>
<?php
include('ads/link.php');
?>

<div class="col-lg-4 col-lg-offset-4">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Join Group</strong></h3></div> 
   <div class="well">
      <div align="center"><h3 class="text-primary">
          <img src="/jagoanssh.png" height="100" width="100" /></h3>
      <span class="label label-primary"> Group FB JagoanSSH</span><br><br>
     </div>
      <p align="center"><a class="btn btn-primary btn-lg" href="/tembak">Join <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a></p>
   </div>
</div>
</div>
   </div>
</div>
</div>