<div id="where" style="display:none;">Tembak-Telkomsel</div>
<div id="ndexi" style="display:none;">Tembak-Telkomsel</div>
<!-- Main component for a primary marketing message or call to action -->

<!-- START: section -->
  <section class="probootstrap-section">
    <div class="container">
    <p class="text-center">
    <span class="badge badge-success mb-3 p-3">Free SSH VPN Accounts</span>
    <span class="badge badge-warning mb-3 p-3">Unlimited Bandwidth VPS</span>
    <span class="badge badge-primary mb-3 p-3">Full Speed Servers</span>
    <span class="badge badge-success mb-3 p-3">Private Account</span>
    <span class="badge badge-info mb-3 p-3">Hide Your IP Adrres</span>
    <span class="badge badge-primary mb-3 p-3">Fast SSH  VPN Servers</span>
  </p> 
  <p class="text-center">
    <span class="label label-danger">No DDOS</span>
    <span class="label label-danger">No Fraud</span>
    <span class="label label-danger">No Hacking</span>
    <span class="label label-danger">No Spam</span>
  </p> 
</div>  
</section>
<!-- END: section -->
<?php
include('app/ads/link.php');
?>
<!-- START: section -->
  <section class="probootstrap-section">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 section-heading mb50 text-center probootstrap-animate">
          <h2>Kenapa Harus Tembak Paket Data?</h2>
          <p class="lead">Beberapa keuntungan dengan tembak paket data</p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-wallet"></i> <span>Harga Lebih Murah</span></h3>
          <p>Harga lebih murah dan kami menyediakan banyak pilihan paket diskon</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-credit-card"></i> <span>System Pembayaran</span></h3>
          <p>Semua pembelian paket data langsung memotong pulsa dari pengguna</p>
        </div>
        <div class="clearfix visible-sm-block"></div>
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-key"></i> <span>System Keamanan</span></h3>
          <p>Website ini tidak pernah menyimpan semua data pengguna yang melakukan pembelian paket data</p>
        </div>
        <div class="clearfix visible-md-block"></div>
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-checkmark"></i> <span>Pembelian Legal</span></h3>
          <p>Semua pembelian paket data di lakukan dari server provider</p>
        </div>
        <div class="clearfix visible-sm-block"></div>
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-hour-glass2"></i> <span>Beli Kapan Saja</span></h3>
          <p>Anda bisa membeli paket data kapan saja selama system online</p>
        </div>
        <div class="col-md-4 col-sm-6 col-xs-12 probootstrap-animate">
          <h3 class="heading-with-icon"><i class="icon-users2"></i> <span>Kirim Paket</span></h3>
          <p>Anda bisa membeli paket data untuk teman atau pun keluarga anda</p>
        </div>
        <div class="clearfix visible-sm-block"></div>
      </div>
    </div>
  </section>
  <!-- END: section -->

<?php
include('app/ads/ads.php');
?>

<div class="col-md-6 col-md-offset-3 probootstrap-section probootstrap-animate" data-animate-effect="fadeInRight">
  <div class="probootstrap-pricing popular">
            <h1><?php echo $row->description ?></h1>
             <img src="https://pbs.twimg.com/profile_images/975350015064354816/hVH80E7s_400x400.jpg" height="100" width="100"/>
             <h3>Paket Data Telkomsel</h3>
              <ul>
              <li>Pembelian Otomatis</li>
              <li>Pembayaran Potong Pulsa</li>
              <li>Gratis</li>
            </ul>
    <a class="btn btn-primary" href="/telkom">Lanjut</a>
</div>
</div>
</div>
<!-- END page -->