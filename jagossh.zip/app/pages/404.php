<br>
<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Superfast Servers</strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-rocket fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>

<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Lifetime Protection </strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-clock-o fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>

<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Secure all connections </strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-wifi fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>

<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Anonymize your activities </strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-eye-slash fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>

<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>Super Data Protection </strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-lock fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>

<div class="col-sm-2 col-md-2">
    <div class="panel panel-primary">
    <div class="panel-heading"> <h3 class="panel-title text-center "><strong>freedom Your Content </strong></h3></div> 
   <div class="well">
      <div align="center"><i class="fa fa-globe fa-4x" aria-hidden="true"></i></h3></div>
   </div>
</div>
</div>
<br>
<br>
</div>