<!-- START: section -->
  <section class="probootstrap-section">
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 section-heading mb50 text-center probootstrap-animate">
          <h1>Free SSH Accounts and Free VPN Accounts</h1>
          <h2>We provide best experience for you</h2>
          <p class="lead">Get an SSH VPN account with super fast speed</p>
          <p class="lead">Free SSH account with the best quality</p>
        </div>
      </div>
<p>
<?php
include('app/ads/ads.php');
?>
</p>
    <p class="text-center probootstrap-animate">
    <span class="badge badge-success mb-3 p-3">Free SSH VPN Accounts</span>
    <span class="badge badge-warning mb-3 p-3">Unlimited Bandwidth VPS</span>
    <span class="badge badge-primary mb-3 p-3">Full Speed Servers</span>
    <span class="badge badge-success mb-3 p-3">Private Account</span>
    <span class="badge badge-info mb-3 p-3">Hide Your IP Adrres</span>
    <span class="badge badge-primary mb-3 p-3">Fast SSH  VPN Servers</span>
  </p> 
  <p class="text-center probootstrap-animate">
    <span class="label label-danger">No DDOS</span>
    <span class="label label-danger">No Fraud</span>
    <span class="label label-danger">No Hacking</span>
    <span class="label label-danger">No Spam</span>
  </p> 
</div>
</section>
<!-- END: section -->
<?php
include('app/ads/link.php');
?>
<section class="probootstrap-section">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center section-heading probootstrap-animate">
          <div class="col-lg-6 col-lg-offset-3 probootstrap-animate">
          <div class="probootstrap-box">
              <h1><b>Closed</b></h1>
              <div class="icon"><i class="icon-stop"></i></div>
              <h2>Layanan di tutup</h2>
              <p class="lead">Sorry, Layanan di tutup sementara oleh admin</p>
              <p class="lead">Silahkan kembali lagi nanti</p>
              <p class="lead">Terimakasih</p>
              <a class="btn btn-primary" href="/">Home Page</a>
          </div>
        </div>
    </div>
</section>
<!-- END: section -->