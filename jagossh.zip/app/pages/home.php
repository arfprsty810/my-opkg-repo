<div id="where" style="display:none;">home</div>
<div id="ndexi" style="display:none;">home</div>
<!-- Main component for a primary marketing message or call to action -->
<script type="text/javascript">
<!--
document.write(unescape('%3c%73%63%72%69%70%74%20%74%79%70%65%3d%22%74%65%78%74%2f%6a%61%76%61%73%63%72%69%70%74%22%3e%0d%0a%20%66%75%6e%63%74%69%6f%6e%20%74%69%6d%65%64%4d%73%67%28%29%0d%0a%20%20%7b%0d%0a%20%20%20%20%76%61%72%20%74%3d%73%65%74%49%6e%74%65%72%76%61%6c%28%22%63%68%61%6e%67%65%5f%74%69%6d%65%28%29%3b%22%2c%31%30%30%30%29%3b%0d%0a%20%20%7d%0d%0a%20%66%75%6e%63%74%69%6f%6e%20%63%68%61%6e%67%65%5f%74%69%6d%65%28%29%0d%0a%20%7b%0d%0a%20%20%20%76%61%72%20%64%20%3d%20%6e%65%77%20%44%61%74%65%28%29%3b%0d%0a%20%20%20%76%61%72%20%63%75%72%72%5f%68%6f%75%72%20%3d%20%64%2e%67%65%74%48%6f%75%72%73%28%29%3b%0d%0a%20%20%20%76%61%72%20%63%75%72%72%5f%6d%69%6e%20%3d%20%64%2e%67%65%74%4d%69%6e%75%74%65%73%28%29%3b%0d%0a%20%20%20%76%61%72%20%63%75%72%72%5f%73%65%63%20%3d%20%64%2e%67%65%74%53%65%63%6f%6e%64%73%28%29%3b%0d%0a%20%20%20%69%66%28%63%75%72%72%5f%68%6f%75%72%20%3e%20%31%32%29%0d%0a%20%20%20%20%20%63%75%72%72%5f%68%6f%75%72%20%3d%20%63%75%72%72%5f%68%6f%75%72%20%2d%20%31%32%3b%0d%0a%20%20%20%64%6f%63%75%6d%65%6e%74%2e%67%65%74%45%6c%65%6d%65%6e%74%42%79%49%64%28%27%48%6f%75%72%27%29%2e%69%6e%6e%65%72%48%54%4d%4c%20%3d%63%75%72%72%5f%68%6f%75%72%2b%27%3a%27%3b%0d%0a%20%20%20%64%6f%63%75%6d%65%6e%74%2e%67%65%74%45%6c%65%6d%65%6e%74%42%79%49%64%28%27%4d%69%6e%75%74%27%29%2e%69%6e%6e%65%72%48%54%4d%4c%3d%63%75%72%72%5f%6d%69%6e%2b%27%3a%27%3b%0d%0a%20%20%20%64%6f%63%75%6d%65%6e%74%2e%67%65%74%45%6c%65%6d%65%6e%74%42%79%49%64%28%27%53%65%63%6f%6e%64%27%29%2e%69%6e%6e%65%72%48%54%4d%4c%3d%63%75%72%72%5f%73%65%63%3b%0d%0a%20%7d%0d%0a%74%69%6d%65%64%4d%73%67%28%29%3b%20%20%20%0d%0a%3c%2f%73%63%72%69%70%74%3e'));
//-->
</script>
<section class="probootstrap-section">
    <div class="container">
    <div class="col-md-8 col-md-offset-2 section-heading">
    <p class="text-center">
  <span class="btn btn-outline-warning">
  <a style="font-size:large;">Resset Time: 00:00:00 GMT -5</a></span>
  <span class="btn btn-outline-primary">
  <a style="font-size:large;">Tiempo del Servidor:</a>
  <a id="Hour" style="font-size:large;"></a>
  <a id="Minut" style="font-size:large;"></a>
  <a id="Second" style="font-size:large;"></a>
  </span>
   </div>
  </div>
</section>
<?php
?>
 <!-- START: section -->
<section class="bg-white py-10" id="service">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8" data-aos="fade-up">
        <div class="text-center mb-3">
          <h2 class="font-weight-bold">Consigue el tuyo ahora</h2>
          <p class="lead">Simplemente elija el servicio que desea.</p>
        </div>
      </div>
    </div>
    <div id="wrapfabtest">
      <div class="adBanner"></div>
      <div data-aos="fade-up" id="consider"></div>
    </div>
    <div data-aos="fade-right" class="text-center mb-5">
    </div>
    <div class="row mb-5" data-aos="fade-down">
      <div class="col-lg-4 mb-5">
        <div class="card card-link border-top border-top-lg border-primary lift text-center o-visible h-100">
          <div class="card-body">
            <div class="icon-stack icon-stack-xl bg-primary-soft text-primary mb-4 mt-n5 z-1 shadow"><i data-feather="cloud"></i></div>
            <h3 class="font-weight-bold mb-3">SSH 3 Dias</h3>
             <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
              <div>Banda ancha Ilimitada</div>
              <div>Servidor Dedicado</div>
              <div>Muy seguro y muy rápido</div>
            <div class="badge badge-pill badge-light font-weight-normal px-3 py-2">Servidor SSH</div>
          </div>
          <div class="card-footer">
            <div class="text-primary font-weight-bold d-inline-flex align-items-center">
              <a class="btn btn-primary btn-marketing rounded-pill" href="<?php urlPrefix('ssh-servers') ?>">Seleccionar Servidor<i data-feather="arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-5">
        <div class="card card-link border-top border-top-lg border-teal lift text-center o-visible h-100">
          <div class="card-body">
            <div class="icon-stack icon-stack-xl bg-teal-soft text-teal mb-4 mt-n5 z-1 shadow"><i data-feather="cloud-snow"></i></div>
            <h3 class="font-weight-bold mb-3">SSH 30 Dias</h3>
             <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
             <div>Banda ancha Ilimitada</div>
              <div>Servidor Dedicado</div>
              <div>Muy seguro y muy rápido</div>
            <div class="badge badge-pill badge-light font-weight-normal px-3 py-2">Servidor SSH</div>
          </div>
          <div class="card-footer">
            <div class="text-teal font-weight-bold d-inline-flex align-items-center">
              <a class="btn btn-primary btn-marketing rounded-pill" href="<?php urlPrefix('30day-ssh') ?>">Seleccionar Servidor<i data-feather="arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-5">
        <div class="card card-link border-top border-top-lg border-warning lift text-center o-visible h-100">
          <div class="card-body">
            <div class="icon-stack icon-stack-xl bg-warning-soft text-warning mb-4 mt-n5 z-1 shadow"><i data-feather="shield"></i></div>
            <h3 class="font-weight-bold mb-3">V2Ray</h3>
             <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
                <div>Banda ancha Ilimitada</div>
              <div>Servidor dedicado</div>
              <div>Muy seguro y muy rápido</div>
 <div class="badge badge-pill badge-light font-weight-normal px-3 py-2">Servidor V2ray</div>
          </div>
          <div class="card-footer">
            <div class="text-teal font-weight-bold d-inline-flex align-items-center">
              <a class="btn btn-primary btn-marketing rounded-pill" href="https://t.me/hablessh">Seleccionar Servidor<i data-feather="arrow-right"></i></a>
          </div>
          </div>
        </div>
      </div>

      </div>
        </div>
        <div class="col-md-3 probootstrap-pricing-wrap">
          <div class="probootstrap-pricing popular">

            <h4 class="title">OVPN 3 Dias</h4>
            <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
            <ul>
              <li>Banda ancha Ilimitada</li>
              <li>Soporta Websocket</li>
              <li>Servidor Dedicado</li>
              <li>Muy seguro y muy rápido</li>
            </ul>

            <p><a href="<?php urlPrefix('vpn-servers') ?>" class="btn btn-primary">Seleccionar Servidor</a></p>

          </div>
        </div>
                <div class="col-md-3 probootstrap-pricing-wrap">
          <div class="probootstrap-pricing popular">

            <h4 class="title">Websocket 3 Dias</h4>
            <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
            <ul>
              <li>Banda ancha Ilimitada</li>
              <li>Servidor Dedicado</li>
              <li>Muy seguro y muy rápido</li>
            </ul>

            <p><a href="<?php urlPrefix('websocketssh') ?>" class="btn btn-primary">Seleccionar Servidor</a></p>

          </div>
        </div>
                <div class="col-md-3 probootstrap-pricing-wrap">
          <div class="probootstrap-pricing popular">

                <h4 class="title">Websocket 7 Dias</h4>
            <div class="probootstrap-price-wrap">
              <span class="probootstrap-price">Gratis</span>
            </div>
            <ul>
              <li>Banda ancha Ilimitada</li>
              <li>Servidor Dedicado</li>
              <li>Muy seguro y muy rápido</li>
            </ul>

            <p><a href="<?php urlPrefix('7day-websocket') ?>" class="btn btn-primary">Seleccionar Servidor</a></p>
         </div>
        </div>
  </section>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
  <div class="svg-border-waves text-primary">
    <svg class="wave" style="pointer-events: none" fill="currentColor" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1920 75">
      <defs>
        <style>
          .a {
            fill: none;
          }

          .b {
            clip-path: url(#a);
          }

          .d {
            opacity: 0.5;
            isolation: isolate;
          }
        </style>
        <clippath id="a">
          <rect class="a" width="1920" height="75"></rect>
        </clippath>
      </defs>
      <title>wave</title>
      <g class="b">
        <path class="c" d="M1963,327H-105V65A2647.49,2647.49,0,0,1,431,19c217.7,3.5,239.6,30.8,470,36,297.3,6.7,367.5-36.2,642-28a2511.41,2511.41,0,0,1,420,48"></path>
      </g>
      <g class="b">
        <path class="d" d="M-127,404H1963V44c-140.1-28-343.3-46.7-566,22-75.5,23.3-118.5,45.9-162,64-48.6,20.2-404.7,128-784,0C355.2,97.7,341.6,78.3,235,50,86.6,10.6-41.8,6.9-127,10"></path>
      </g>
      <g class="b">
        <path class="d" d="M1979,462-155,446V106C251.8,20.2,576.6,15.9,805,30c167.4,10.3,322.3,32.9,680,56,207,13.4,378,20.3,494,24"></path>
      </g>
      <g class="b">
        <path class="d" d="M1998,484H-243V100c445.8,26.8,794.2-4.1,1035-39,141-20.4,231.1-40.1,378-45,349.6-11.6,636.7,73.8,828,150"></path>
      </g>
    </svg>
  </div>
</section>
  <!-- END section -->

<!-- END PAGE -->