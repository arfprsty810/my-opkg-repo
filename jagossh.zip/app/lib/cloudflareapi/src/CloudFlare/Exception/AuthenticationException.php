<?php

namespace Cloudflare\Exception;

class AuthenticationException extends \RuntimeException
{
}
