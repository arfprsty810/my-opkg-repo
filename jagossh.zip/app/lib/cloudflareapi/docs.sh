#This should be run on the gh-pages branch, saved here for future reference
#find . -path ./.git -prune -o -exec rm -rf {} \; 2> /dev/null
#apigen generate -s ../cloudflare/src -d .